public interface INotificationService
{
        void Notify(Guid customerId, string message);
}